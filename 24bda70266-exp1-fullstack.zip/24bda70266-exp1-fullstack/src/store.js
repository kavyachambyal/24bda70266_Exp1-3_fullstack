import { configureStore, createSlice } from '@reduxjs/toolkit'

const STORAGE_KEY = 'post-composer-state'
const defaultComposer = {
  title: '',
  body: '',
  platforms: ['Instagram', 'X'],
}

const sampleDraft = {
  id: 'draft-sample',
  title: 'Launch week teaser',
  body:
    'We are preparing a playful campaign for Instagram and X that highlights the launch countdown and the first look at the experience.',
  platforms: ['Instagram', 'X'],
  createdAt: '2026-07-10T09:30:00.000Z',
  updatedAt: '2026-07-10T09:30:00.000Z',
}

const createInitialState = () => ({
  drafts: [sampleDraft],
  activeDraftId: 'draft-sample',
  composer: {
    ...defaultComposer,
    title: sampleDraft.title,
    body: sampleDraft.body,
    platforms: sampleDraft.platforms,
  },
})

const loadInitialState = () => {
  if (typeof window === 'undefined') {
    return createInitialState()
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) {
      return createInitialState()
    }

    const parsed = JSON.parse(raw)
    return {
      drafts: parsed.drafts ?? [sampleDraft],
      activeDraftId: parsed.activeDraftId ?? null,
      composer: {
        ...defaultComposer,
        ...(parsed.composer ?? {}),
      },
    }
  } catch {
    return createInitialState()
  }
}

const postsSlice = createSlice({
  name: 'posts',
  initialState: loadInitialState(),
  reducers: {
    updateComposer: (state, action) => {
      state.composer = { ...state.composer, ...action.payload }
    },
    setPlatforms: (state, action) => {
      state.composer.platforms = action.payload
    },
    saveDraft: (state, action) => {
      const draft = action.payload
      const stamp = new Date().toISOString()
      const existing = state.drafts.find((item) => item.id === draft.id)

      if (existing) {
        Object.assign(existing, { ...draft, updatedAt: stamp })
      } else {
        state.drafts.unshift({ ...draft, createdAt: stamp, updatedAt: stamp })
      }

      state.activeDraftId = draft.id
      state.composer = {
        ...state.composer,
        title: draft.title,
        body: draft.body,
        platforms: draft.platforms,
      }
    },
    loadDraft: (state, action) => {
      const draft = action.payload
      state.activeDraftId = draft.id
      state.composer = {
        title: draft.title,
        body: draft.body,
        platforms: draft.platforms,
      }
    },
    deleteDraft: (state, action) => {
      state.drafts = state.drafts.filter((draft) => draft.id !== action.payload)
      if (state.activeDraftId === action.payload) {
        state.activeDraftId = null
        state.composer = { ...defaultComposer }
      }
    },
    clearComposer: (state) => {
      state.activeDraftId = null
      state.composer = { ...defaultComposer }
    },
  },
})

export const { updateComposer, setPlatforms, saveDraft, loadDraft, deleteDraft, clearComposer } =
  postsSlice.actions

export const store = configureStore({
  reducer: postsSlice.reducer,
})

store.subscribe(() => {
  if (typeof window !== 'undefined') {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(store.getState()))
  }
})
