import { useMemo, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { clearComposer, deleteDraft, loadDraft, saveDraft, setPlatforms, updateComposer } from './store'
import './App.css'

const platformRules = {
  Instagram: {
    maxLength: 2200,
    minLength: 10,
    hashtags: 5,
    media: '1–10 images or 1 video',
  },
  X: {
    maxLength: 280,
    minLength: 1,
    hashtags: 2,
    media: 'Up to 4 images',
  },
  LinkedIn: {
    maxLength: 3000,
    minLength: 20,
    hashtags: 3,
    media: '1 image or document',
  },
  Facebook: {
    maxLength: 63206,
    minLength: 5,
    hashtags: 4,
    media: 'Up to 20 images',
  },
}

const platformOptions = Object.keys(platformRules)

function App() {
  const dispatch = useDispatch()
  const { composer, drafts, activeDraftId } = useSelector((state) => state)
  const [feedback, setFeedback] = useState('')

  const validation = useMemo(() => {
    const text = composer.body.trim()
    const title = composer.title.trim()
    const selectedPlatforms = composer.platforms || []

    const errors = []
    const warnings = []

    if (!title) {
      errors.push('Add a title so the draft is easy to recognize.')
    }

    if (text.length < 10) {
      errors.push('The post body is too short for a polished publish-ready message.')
    }

    selectedPlatforms.forEach((platform) => {
      const rule = platformRules[platform]
      if (!rule) return
      if (text.length > rule.maxLength) {
        errors.push(`${platform} posts can only use ${rule.maxLength} characters.`)
      }
      if (text.length < rule.minLength) {
        warnings.push(`${platform} needs at least ${rule.minLength} characters.`)
      }
      const hashtagCount = (text.match(/#/g) || []).length
      if (hashtagCount > rule.hashtags) {
        warnings.push(`${platform} should keep hashtags to ${rule.hashtags} or fewer.`)
      }
    })

    if (!selectedPlatforms.length) {
      errors.push('Choose at least one platform for publishing.')
    }

    const status = errors.length ? 'error' : warnings.length ? 'warning' : 'valid'

    return { errors, warnings, status }
  }, [composer.body, composer.title, composer.platforms])

  const handlePlatformToggle = (platform) => {
    const next = composer.platforms.includes(platform)
      ? composer.platforms.filter((item) => item !== platform)
      : [...composer.platforms, platform]
    dispatch(setPlatforms(next))
  }

  const handleSave = () => {
    const id = activeDraftId || `draft-${Date.now()}`
    const draft = {
      id,
      title: composer.title,
      body: composer.body,
      platforms: composer.platforms,
    }
    dispatch(saveDraft(draft))
    setFeedback('Draft saved successfully and ready to revisit.')
  }

  const handleLoad = (draft) => {
    dispatch(loadDraft(draft))
    setFeedback(`Loaded “${draft.title}” from drafts.`)
  }

  const handleDelete = (id) => {
    dispatch(deleteDraft(id))
    setFeedback('Draft removed from the list.')
  }

  const handleClear = () => {
    dispatch(clearComposer())
    setFeedback('Composer cleared and ready for a fresh post.')
  }

  const charCount = composer.body.length
  const isReady = validation.status === 'valid'

  return (
    <div className="app-shell">
      <header className="hero-card">
        <div>
          <p className="eyebrow">Multi-platform content studio</p>
          <h1>Compose once, publish confidently.</h1>
          <p className="subtitle">
            Design posts that adapt to Instagram, X, LinkedIn, and Facebook with instant validation,
            live counters, and a draft workflow shaped for modern teams.
          </p>
        </div>
        <div className="hero-badge">Live validation</div>
      </header>

      <section className="content-grid">
        <article className="panel composer-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Post composer</p>
              <h2>Build your publish-ready message</h2>
            </div>
            <span className={`status-pill ${validation.status}`}>{validation.status}</span>
          </div>

          <label className="field">
            <span>Title</span>
            <input
              value={composer.title}
              onChange={(event) => dispatch(updateComposer({ title: event.target.value }))}
              placeholder="Add a clear title"
            />
          </label>

          <label className="field">
            <span>Post body</span>
            <textarea
              value={composer.body}
              onChange={(event) => dispatch(updateComposer({ body: event.target.value }))}
              rows={8}
              placeholder="Write your post content here..."
            />
          </label>

          <div className="field">
            <span>Target platforms</span>
            <div className="chip-group">
              {platformOptions.map((platform) => (
                <button
                  key={platform}
                  type="button"
                  className={`chip ${composer.platforms.includes(platform) ? 'active' : ''}`}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  {platform}
                </button>
              ))}
            </div>
          </div>

          <div className="stats-row">
            <div>
              <strong>{charCount}</strong>
              <span>characters</span>
            </div>
            <div>
              <strong>{composer.platforms.length}</strong>
              <span>platforms</span>
            </div>
            <div>
              <strong>{isReady ? 'Ready' : 'Review'}</strong>
              <span>publish state</span>
            </div>
          </div>

          <div className="actions">
            <button type="button" className="primary" onClick={handleSave}>
              Save draft
            </button>
            <button type="button" className="secondary" onClick={handleClear}>
              Clear
            </button>
          </div>

          <div className="feedback-box">
            {feedback && <p className="feedback">{feedback}</p>}
            {validation.errors.length > 0 && (
              <ul>
                {validation.errors.map((error) => (
                  <li key={error}>{error}</li>
                ))}
              </ul>
            )}
            {validation.warnings.length > 0 && (
              <ul className="warning-list">
                {validation.warnings.map((warning) => (
                  <li key={warning}>{warning}</li>
                ))}
              </ul>
            )}
          </div>
        </article>

        <aside className="panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Draft manager</p>
              <h2>Saved drafts</h2>
            </div>
          </div>

          <div className="draft-list">
            {drafts.map((draft) => (
              <div key={draft.id} className={`draft-card ${draft.id === activeDraftId ? 'active-draft' : ''}`}>
                <div>
                  <h3>{draft.title}</h3>
                  <p>{draft.body.slice(0, 90)}{draft.body.length > 90 ? '…' : ''}</p>
                  <small>{draft.platforms.join(' • ')}</small>
                </div>
                <div className="draft-actions">
                  <button type="button" onClick={() => handleLoad(draft)}>
                    Open
                  </button>
                  <button type="button" onClick={() => handleDelete(draft.id)}>
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </section>
    </div>
  )
}

export default App
